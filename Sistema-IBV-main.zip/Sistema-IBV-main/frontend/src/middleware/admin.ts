import { useAuthStore } from '~/stores/auth'

export default defineNuxtRouteMiddleware(async () => {
  if (process.server) return

  const authStore = useAuthStore()

  if (!authStore.token) {
    return navigateTo('/login')
  }

  if (!authStore.user) {
    await authStore.loadUser()
  }

  if (authStore.user?.role !== 'admin') {
    return navigateTo('/')
  }
})
